class ApiKeys {
  static const String pixabay = "55171562-705abe800f6f77eb9f3375728";
}